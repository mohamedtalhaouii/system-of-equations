<h1 align="center">
    <img src="https://readme-typing-svg.herokuapp.com/?font=Righteous&size=35&center=true&vCenter=true&width=500&height=70&duration=4000&lines=Hi+There!+👋;+I'm+Mohamed+Talhaoui!;" />
</h1>
<h3 align="center">I'm a CS Student 🧑🏻‍💻</h3>

<p align="left"> <img src="https://komarev.com/ghpvc/?username=mohamedtalhaouii&label=Profile%20views&color=0e75b6&style=flat" alt="mohamedtalhaouii" /> </p>

- 🐍 I’m currently learning **Python**

- 📝 I regularly write articles on https://mohamedtalhaoui.me/blog

- 📨 How to reach me **mohamedtalhaouii@outlook.com**


<hr>

<h3 align="center">Connect with me :</h3>
<p align="center">
<a href="https://twitter.com/taalhaoui" target="_blank"><img align="center" src="https://skillicons.dev/icons?i=twitter" alt="taalhaoui" height="30" width="40" /></a>
<a href="https://linkedin.com/in/mohamedtalhaoui" target="_blank"><img align="center" src="https://skillicons.dev/icons?i=linkedin" alt="mohamedtalhaoui" height="30" width="40" /></a>
<a href="https://fb.com/mohamedtalhaouiii" target="_blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/facebook.svg" alt="mohamedtalhaouiii" height="30" width="40" /></a>
<a href="https://instagram.com/mohamedtalhaouii" target="_blank"><img align="center" src="https://skillicons.dev/icons?i=instagram" alt="mohamedtalhaouii" height="30" width="40" /></a>
</p>

<hr>

<h3 align="center">Languages and Tools :</h3>
<div align="center">
    <img src="https://skillicons.dev/icons?i=html,css,javascript,figma,vscode,github,python,cpp&perline=8" />
</div>

<hr>
<h3 align="center">Support :</h3>
<p align="center"><a href="https://www.buymeacoffee.com/mohamedtalhaoui"> <img align="center" src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" height="50" width="210" alt="mohamedtalhaoui" /></a></p><br>
<hr>



<div align=center>
  <img width=390 src="https://github-readme-streak-stats-salesp07.vercel.app/?user=mohamedtalhaouii&count_private=true&theme=react&border_radius=10" alt="streak stats"/>
  <img width=390 src="https://github-readme-stats-salesp07.vercel.app/api?username=mohamedtalhaouii&count_private=true&show_icons=true&theme=react&rank_icon=github&border_radius=10" alt="readme stats" />
  <br/>
  <img width=325 align="center" src="https://github-readme-stats-salesp07.vercel.app/api/top-langs/?username=mohamedtalhaouii&hide=HTML&langs_count=8&layout=compact&theme=react&border_radius=10&size_weight=0.5&count_weight=0.5&exclude_repo=github-readme-stats" alt="top langs" />
</div>
